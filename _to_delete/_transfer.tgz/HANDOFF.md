# Handoff

Context for continuing this project in a fresh session.

**To resume:** open this repo in Claude Code and say *"Read HANDOFF.md and continue."*
Copy this file to `CLAUDE.md` if you want it loaded automatically every session.

---

## What this is

A browser-only musical instrument played with hand gestures in front of a
webcam. Two hands tracked at ~30 fps: left picks harmony, right shapes
expression. Fully client-side — no server, no API keys, nothing uploaded.
Deploys as static files.

The original brief is in **`BUILD-SPEC.md`** in this directory. It is the
authority on intended behaviour; read it before changing core behaviour.

---

## Environment gotcha (hit this first)

`node` is **not on PATH** in this shell. It lives under nvm:

```fish
set -x PATH $HOME/.nvm/versions/node/v24.15.0/bin $PATH
```

Shell is fish. macOS.

1. col1col2col3

## Commands

1. CommandWhat`npm run dev`http://localhost:5173`npm test`118 unit tests, no camera/browser needed`npm run test:e2e`~57 assertions in real Chrome (fake camera device)`npm run build`typecheck + production bundle`npm run vendor`re-fetch MediaPipe model + piano samples into`public/node e2e/shots.mjs`manual: screenshots of each UI state (`OUT=./shots`)

`npm install` vendors ~20 MB (MediaPipe wasm + hand model) and ~1.8 MB (piano
samples) into `public/`. Deploy needs **HTTPS** — `getUserMedia` won't run over
plain HTTP. `localhost` is exempt.

---

## Architecture

```
src/
  vision/     MediaPipe lifecycle, geometry, gesture classification, filtering
  music/      keys, scales, chords, voice leading, ragas, talas  (pure, no Tone)
  audio/      Tone.js graph, instruments, arpeggiator, bass, metronome, tanpura
  modes/      gesture / theremin / mono piano / raga / keyboard
  engine/     Conductor — the single rAF loop, wires everything
  recording/  MediaRecorder + canvas compositing
  state/      zustand store (settings) + telemetry (per-frame, non-React)
  ui/         React panels and HUD + imperative skeleton renderer
```

**The one rule: React never owns per-frame data.** Landmarks, skeleton drawing
and audio-parameter updates run outside React in one rAF loop owned by
`engine/Conductor.ts`. Discrete rare events (chord change, hand appears) go
through the zustand store; anything per-frame goes through
`state/telemetry.ts`, a mutable singleton polled by whoever needs it. Pushing
30 fps through `setState` drops frames.

**Where the risk concentrates:** `vision/smoothing.ts` (One Euro for continuous
values, asymmetric hysteresis for discrete ones) and `vision/fingers.ts`
(rotation-invariant finger extension). These are the difference between an
instrument and a demo. Both are heavily unit-tested.

**Dev handle:** `window.__gestureSynth` exposes `{ conductor, store, telemetry }`
in dev builds — that's what the e2e suites drive.

---

## Built and working

All milestones M0–M9 from the spec, plus these additions made during the
session:

- **Raga mode** (Hindustani) — 13 ragas, tanpura drone (Karplus-Strong, four
  plucked strings), meend/portamento, 6 talas with sam/tali/khali roles and a
  tabla voice. Aroha vs avaroha is modelled: the same gesture is a different
  swara depending on direction of travel.
- **Chord instruments** — Synth (detuned triple-saw) / Electric piano (FM) /
  Grand piano (sampled Salamander, lazy-loaded 1.8 MB, CC-BY, licence in
  `public/samples/piano/LICENSE.txt` + Help panel credit).
- **Chord blend** slider — moves attack, detune spread, release and reverb
  together, from a crisp stab to a fused pad.
- **HUD rewrite** — card above the controls with a live oscilloscope
  (`Tone.Waveform`, real samples, flat when silent), tala strip, hand pills,
  contextual empty state instead of a bare em-dash.
- **Camera quality setting** (480p/720p/1080p, default 720p) — capture
  resolution is now decoupled from detection resolution. Detection always
  downscales to 640 wide via a canvas, so a sharp preview costs no frame rate.
  Verified: 31.6 fps and 27.3 ms latency at 720p capture.

---

## ⚠️ Open items — do these first

1. **Re-run the full verification.** The last full run was interrupted
   mid-command. Typecheck was clean and the camera + latency e2e checks passed
   individually, but `npm test`, `npm run build` and the complete
   `npm run test:e2e` have not been run since the final camera-quality edits.
   Expect green; confirm before trusting it.
2. **Handedness has never been verified against a physical camera.** This is
   the single biggest untested assumption. `HANDEDNESS_IS_INVERTED` in
   `vision/HandTracker.ts` assumes MediaPipe's labels are inverted relative to
   the player's anatomy (because we feed it raw, unmirrored frames while
   showing a mirrored preview). To check in two seconds: Settings → Developer
   panel → hold up **only your left hand** → the HUD's **Harmony** pill should
   light. If **Expression** lights instead, flip that one boolean. End users
   have the **Swap Hands** toggle regardless.
3. **Rename pending** (user asked for suggestions; shortlist below). If renaming,
   touch: `package.json` name, `index.html` `<title>`, the localStorage key
   `gesture-synth.settings` in `state/store.ts` (bump `version` or migrate so
   existing settings don't silently reset), the download filename
   `gesture-synth.{ext}` in `ui/RecordControls.tsx`, and README/HANDOFF headings.

---

## Name shortlist

Current name collides with the reference app (gesturesynthweld.com).

| Name                | Why                                                                                                                                                                                                                                                                                                                               |
| ------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Mudra**     | Sanskrit for hand gesture/seal; the hand positions of Indian classical dance and music. Literally what the app is, two syllables, globally pronounceable, ties the raga mode to the whole.**Caveat:** "Mudra Band" is an existing neural-input wristband — same gesture-input space, so check trademark before committing. |
| **Antara**    | The second section of a Hindustani composition; also Sanskrit for*interval / the space between*. Double meaning fits a two-handed instrument. Less collision risk than Mudra.                                                                                                                                                   |
| **Hasta**     | Sanskrit for "hand" (as in hasta mudra). Clean and short.                                                                                                                                                                                                                                                                         |
| **Swarhast**  | *swar* (note) + *hast* (hand). Coined, so almost certainly free; slightly harder for non-Indian speakers.                                                                                                                                                                                                                     |
| **Vaayu**     | Wind/air — playing into empty air.                                                                                                                                                                                                                                                                                               |
| **Aerochord** | Plain-English descriptive, no cultural framing.                                                                                                                                                                                                                                                                                   |

Recommendation: **Mudra** if the trademark check comes back clean, **Antara**
otherwise.

---

## Deviations from BUILD-SPEC.md

Documented in full in README under "Deviations from the spec". Summary:

1. A ninth chord style, `Diatonic (follows key)`, is the default — the spec's
   eight fixed styles force every degree to one quality, which broke its own
   success criterion ("three fingers → a iii chord").
2. Two files not in the spec's layout: `engine/Conductor.ts` and
   `modes/types.ts`. The spec's file list had no home for either.
3. Mono Piano triggers on pinch only; flick needs a velocity estimate that
   landmark jitter makes unreliable at 30 fps.

Not built: **Web MIDI output**. It appears only in the spec's "Reader notes
(not part of the prompt)", so it was out of scope — but it is a good idea and
would sit cleanly on `audio/voices.ts`, which already computes note-level
attack/release deltas. Roughly 100 lines.

---

## Still worth doing by hand

No automated harness covers these:

- The manual browser matrix (Chrome + Firefox, macOS + Windows, bright and dim
  rooms) with a real pair of hands.
- Threshold tuning against real footage. Use the developer panel's **landmark
  replay**: record raw landmarks to JSON, then replay them through the whole
  pipeline with no camera, so tuning is repeatable.
- Lighthouse accessibility pass (spec target: >90).
