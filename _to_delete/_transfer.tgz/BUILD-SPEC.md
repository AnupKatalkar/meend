# Build Prompt: Gesture Synth (webcam hand-tracking musical instrument)

Paste everything below the horizontal rule into Claude Code (or another coding agent) as the opening instruction. It is written as a direct brief to the implementer. Notes for you, the human, are collected at the very bottom under "Reader notes".

---

## 0. Mission

Build a browser-only musical instrument played with hand gestures in front of a webcam. Two hands are tracked at ~30 fps. The left hand picks harmony, the right hand shapes expression. Nothing leaves the device: no uploads, no backend, no analytics on video frames. The whole thing is a static site.

Reference behaviour is the public Gesture Synth app (https://gesturesynthweld.com/). Match its feature set. Do not copy its source, markup, or assets; build from this spec.

Success looks like: a stranger opens the URL, grants camera access, holds up three fingers on their left hand, and hears a iii chord within two seconds, with no tutorial.

## 1. Hard constraints

- Client-side only. No server, no API keys, no database. Deployable as static files to any CDN.
- Camera frames and landmark data never leave the browser. State this in the UI.
- Must run over HTTPS (getUserMedia requirement). localhost is exempt during development.
- Works without a camera: a keyboard fallback mode is a first-class feature, not a stub.
- Audio must not start before a user gesture (browser autoplay policy). Gate `Tone.start()` behind the first click or key press.
- Target: Chrome and Edge on desktop as primary; Firefox and Safari should work with graceful degradation. Mobile is best-effort, not a target.

## 2. Stack

```
vite            ^8
react           ^19
typescript      ^7
@mediapipe/tasks-vision  ^1.0
tone            ^15
zustand         ^5      (single global store; do not reach for Redux)
tailwindcss     ^4      (styling; plain CSS modules acceptable if you prefer)
```

Verify these versions resolve at install time and adjust if the registry disagrees. Do not use the legacy `@mediapipe/hands` package; it is the old Solutions API and is superseded by Tasks Vision.

Vendor the MediaPipe wasm bundle and the `hand_landmarker.task` model into `public/` rather than pulling from a CDN at runtime. First load pulls tens of megabytes; self-hosting makes that cacheable and keeps the app working offline after first visit. Show a determinate progress indicator while it loads.

## 3. Project layout

```
src/
  main.tsx
  App.tsx
  vision/
    HandTracker.ts        # MediaPipe lifecycle, camera stream, detect loop
    landmarks.ts          # index constants, geometry helpers
    fingers.ts            # finger extension, gesture classification
    smoothing.ts          # EMA + One Euro filter, hysteresis debouncer
    types.ts              # HandFrame, GestureState
  audio/
    AudioEngine.ts        # Tone.js graph construction and teardown
    voices.ts             # chord voice management, retrigger policy
    arpeggiator.ts
    bass.ts
    metronome.ts
  music/
    theory.ts             # keys, scales, degrees, chord formulas
    chords.ts             # degree + style -> note array
  modes/
    gestureMode.ts
    thereminMode.ts
    monoPianoMode.ts
    keyboardMode.ts
  recording/
    Recorder.ts           # MediaRecorder orchestration
    canvasComposer.ts     # aspect-ratio framing, skeleton drawing
  state/
    store.ts              # zustand store: settings + live readouts
  ui/
    CameraView.tsx        # <video> + overlay <canvas>
    SkeletonOverlay.ts    # imperative canvas draw, not React
    SettingsPanel.tsx
    HelpPanel.tsx
    RecordControls.tsx
    HUD.tsx               # current chord, hand detection status, level meter
    Onboarding.tsx
public/
  wasm/                   # mediapipe wasm assets
  models/hand_landmarker.task
```

Rule: React owns settings, panels, and text. React does **not** own per-frame data. Landmarks, skeleton drawing, and audio parameter updates run outside React in a rAF loop and imperative refs. Pushing 30 fps of landmark data through `setState` will drop frames.

## 4. Vision layer

### 4.1 Setup

```ts
import { FilesetResolver, HandLandmarker } from "@mediapipe/tasks-vision";

const vision = await FilesetResolver.forVisionTasks("/wasm");
const landmarker = await HandLandmarker.createFromOptions(vision, {
  baseOptions: { modelAssetPath: "/models/hand_landmarker.task", delegate: "GPU" },
  runningMode: "VIDEO",
  numHands: 2,
  minHandDetectionConfidence: 0.5,
  minHandPresenceConfidence: 0.5,
  minTrackingConfidence: 0.5,
});
```

Fall back to `delegate: "CPU"` if GPU creation throws, and tell the user tracking may be slower.

Detect loop:

```ts
const result = landmarker.detectForVideo(video, performance.now());
```

`detectForVideo` takes a monotonically increasing timestamp in milliseconds. Skip the call when `video.currentTime` has not advanced since the last frame, otherwise MediaPipe will complain about duplicate timestamps and you will waste GPU time.

Camera request: `getUserMedia({ video: { width: 640, height: 480, frameRate: 30 }, audio: false })`. 640x480 is plenty for landmarks and much cheaper than 1080p. Request a separate higher-resolution stream only if the user starts a video recording.

### 4.2 Landmark indices

21 landmarks per hand, normalized x/y in [0,1] with y increasing downward, plus a relative z.

```
0  wrist
1-4    thumb:  CMC, MCP, IP, TIP
5-8    index:  MCP, PIP, DIP, TIP
9-12   middle: MCP, PIP, DIP, TIP
13-16  ring:   MCP, PIP, DIP, TIP
17-20  pinky:  MCP, PIP, DIP, TIP
```

### 4.3 Handedness, and the mirror trap

`result.handedness[i][0].categoryName` is `"Left"` or `"Right"`, computed as if the image were **not** mirrored. The camera preview must be mirrored (`transform: scaleX(-1)`) or the instrument feels wrong to play. So the label MediaPipe gives you and the hand the user perceives on that side of the screen can be inverted depending on how you draw.

Do not guess. Build a two-second calibration check into development: log the label while you hold up one known hand, and pin the mapping with a single `MIRRORED = true` constant and one conversion function. Every other module consumes `hand.role: "harmony" | "expression"`, never a raw label. Add a "swap hands" toggle in settings for left-handed players and for the cases where handedness detection flips.

### 4.4 Finger extension

Naive `tip.y < pip.y` breaks the moment the hand rotates. Use a wrist-distance test, which holds under rotation:

```ts
// finger is extended if the tip is meaningfully farther from the wrist than the PIP joint
const extended = dist(tip, wrist) > dist(pip, wrist) * EXTENSION_RATIO; // start at 1.15
```

The thumb needs its own rule because it abducts sideways rather than curling. Compare the thumb tip's distance to the pinky MCP (17) against the thumb IP's distance to the same point; extended thumbs swing away from the palm. Give the thumb its own threshold constant and expose both constants in a hidden dev panel so they can be tuned against real footage.

Normalize for hand scale before any absolute-distance comparison: divide by `dist(landmark0, landmark9)` (wrist to middle MCP), which is roughly palm length and is invariant to how far the user sits from the camera.

### 4.5 Wrist tilt

Tilt is the angle of the wrist-to-middle-MCP vector away from vertical:

```ts
const angle = Math.atan2(mid9.x - wrist0.x, wrist0.y - mid9.y); // radians, 0 = upright
```

Clamp usable range to roughly ±50°. Map to a unit value in [-1, 1].

### 4.6 Smoothing and debouncing

Two different problems, two different tools. Do not use one filter for both.

**Continuous values** (hand height, tilt) feed audio parameters and need low-latency smoothing without visible lag. Use a One Euro filter (min cutoff ~1.0 Hz, beta ~0.007, derivative cutoff 1.0) per value. An exponential moving average is acceptable as a first pass but will feel either laggy or jittery depending on alpha; One Euro adapts.

**Discrete gestures** (finger count, chord selection) must not flicker. Require the same classification on N consecutive frames before committing, with asymmetric thresholds: 3 frames to enter a new gesture, 6 frames to fall back to "no hand". Never re-trigger a chord because a single frame misread four fingers as three. This hysteresis is the single biggest factor in whether the instrument feels playable or broken.

Track a `handLostAt` timestamp. If a hand disappears for under 250 ms, hold the last state (occlusion, blink of the tracker). Beyond that, release the note.

## 5. Music layer

### 5.1 Keys and scales

Twelve keys, C through B. Default key: A. Major scale intervals in semitones from the root: `[0, 2, 4, 5, 7, 9, 11]`. Natural minor: `[0, 2, 3, 5, 7, 8, 10]`.

Diatonic triad qualities in major: `I ii iii IV V vi vii°`. In natural minor: `i ii° III iv v VI VII`.

### 5.2 Chord styles

Eight fixed styles, each a semitone formula from the chord root:

```
Major Triad     [0, 4, 7]
Minor Triad     [0, 3, 7]
Diminished      [0, 3, 6]
Sus2            [0, 2, 7]
Sus4            [0, 5, 7]
Major 7th       [0, 4, 7, 11]
Dominant 7th    [0, 4, 7, 10]
Major 1st Inv   [4, 7, 12]
```

Finger Layout mode instead derives the style from right-hand finger count:

```
1 finger  -> diatonic triad (quality follows the scale degree)
2 fingers -> first inversion of that triad
3 fingers -> diatonic seventh
4 fingers -> diatonic ninth
```

Base octave: root notes around C4. Thumb extended on the expression hand drops everything one octave.

### 5.3 Voicing

Keep chords in a narrow register so degree changes do not leap. Voice each chord to the inversion whose top note is nearest the previous chord's top note. This is cheap to implement and makes finger-count noodling sound intentional rather than random.

## 6. Audio engine

Build the graph once, on first user gesture, and keep it alive for the session. Never construct Tone nodes inside a render or a per-frame callback.

```
PolySynth(Tone.Synth, { oscillator: { type: "sawtooth" },
                        envelope: { attack: 0.02, decay: 0.15, sustain: 0.7, release: 0.35 } })
  -> Filter (lowpass, rolloff -24, Q 1.2)
  -> Gain  (expression / hand height)
  -> Reverb (wet 0.18, decay 1.8)
  -> Limiter (-3 dB)
  -> Destination

MonoSynth (auto bass, triangle+lowpass) -> its own Gain -> Limiter
MembraneSynth / short noise click (metronome) -> its own Gain -> Limiter
```

Rules that matter:

- **Never set audio params directly from the rAF loop.** Use `param.rampTo(value, 0.03)` or `linearRampToValueAtTime`. Direct assignment at 30 Hz produces zipper noise.
- **Filter cutoff** maps tilt to an exponential curve, roughly 200 Hz at full left to 8000 Hz at full right. Linear frequency mapping sounds wrong; humans hear pitch logarithmically.
- **Volume** maps hand height (inverted normalized y) through a curve, not a straight line. Try `gain = clamp(h, 0, 1) ** 1.5`, then smooth. Add a small dead zone at the bottom so a resting hand is silent.
- **Retrigger policy:** only `triggerAttack` when the committed chord identity actually changes. Everything else (volume, filter, tilt) modulates the sustained voices. Compare chord note arrays, not gesture frames.
- **Fist gesture** releases all voices and holds silence until fingers reappear.
- Cap polyphony at 8 voices and call `releaseAll()` on mode changes to avoid stuck notes.

### 6.1 Arpeggiator

Off / Slow / Normal / Fast, mapping to note rates of `4n`, `8n`, `16n` against the transport BPM. Cycles the current chord's notes upward. When on, the chord voices play one note at a time; when off, all notes sound together. Implement with `Tone.Loop` reading the current chord from a ref, not by scheduling a fixed pattern, so chord changes take effect on the next tick without rebuilding the loop.

### 6.2 Auto bass

Off / On. Plays the chord root two octaves below the chord voicing on a separate mono synth, with its own volume control in settings. Retrigger it on chord change only.

### 6.3 Metronome

BPM 40 to 240, time signatures 4/4, 3/4, 6/8, optional bar count limit, accent on beat one, selectable click sound. Runs on `Tone.Transport`. The arpeggiator shares the same transport so the two stay locked.

## 7. Play modes

Three modes, selectable in settings, mutually exclusive.

### 7.1 Gesture Mode (default)

**Harmony hand (left):** finger count picks the scale degree.

| Gesture | Degree |
|---|---|
| any 1 finger | I |
| any 2 fingers, not the vi combo | ii |
| any 3 fingers, not the vii combo | iii |
| any 4 fingers | IV |
| all 5 fingers | V |
| index + pinky only (middle, ring, thumb down) | vi |
| index + pinky + thumb only (middle, ring down) | vii° |
| closed fist | mute |

Classification order matters: test the exact vi and vii combos **before** falling through to plain finger counts, otherwise index+pinky reads as ii.

Harmony-hand submodes:

- *Scale Only* (default): mode locked to major, tilt ignored.
- *Scale + Tilt*: wrist tilt left selects minor, tilt right selects major. Add a hysteresis band around centre so the mode does not chatter.

**Expression hand (right):**

- Height: volume. Higher is louder.
- Tilt: filter sweep. Right is brighter, left is darker.
- Thumb extended: drop one octave.
- Finger count: chord complexity, but only in *Finger Layout* submode.

Expression-hand submodes:

- *Finger Layout*: finger count picks triad / 1st inversion / 7th / 9th.
- *Fixed Chord Style* (default): style is locked to the settings choice; the right hand only does volume, filter, and octave.

### 7.2 Theremin Mode

Right hand height maps continuously to pitch across C3 to C6. Left hand height maps to volume. Sine oscillator. Add an optional "snap to scale" toggle that quantizes pitch to the selected key; freeform is the default because that is what a theremin does. Use a portamento of ~50 ms so pitch glides rather than steps.

### 7.3 Mono Piano Mode

Left hand picks an interval from the root: root, major third, fifth, octave, ninth (finger counts 1 through 5). Right hand triggers the note, using a pinch (thumb tip to index tip distance below a normalized threshold) or a downward flick. Pinch is more reliable; implement pinch and treat flick as optional. Single voice, piano-ish envelope (fast attack, medium decay, low sustain).

## 8. Keyboard mode

Full parity for anyone without a camera. Toggled in settings and auto-offered when camera access fails.

```
1 - 7        scale degrees I to VII, hold to sustain
[ / ]        minor / major
8 9 0 -      chord style slots
Shift        octave down (hold)
Up / Down    volume
Left / Right filter sweep
Space        panic: release all voices
```

Show an on-screen key map in the help panel with live highlighting of pressed keys. Use `event.code`, not `event.key`, so non-US layouts still work. Prevent default on the arrow keys to stop page scroll.

## 9. Recording

Up to 30 seconds, three capture types:

1. **Audio only**, with an optional microphone mix so users can sing or narrate.
2. **Full video**: mirrored camera feed with the neon skeleton overlay drawn on top, plus audio.
3. **Skeleton only**: black background, skeleton and particles, no camera imagery. This is the privacy-friendly share option and should be prominent.

Implementation:

```ts
const dest = Tone.getContext().rawContext.createMediaStreamDestination();
limiter.connect(dest);                       // tap the master bus
const canvasStream = composeCanvas.captureStream(30);
const mixed = new MediaStream([...canvasStream.getVideoTracks(), ...dest.stream.getAudioTracks()]);
const rec = new MediaRecorder(mixed, { mimeType: pickSupportedMime() });
```

`pickSupportedMime()` probes with `MediaRecorder.isTypeSupported` in order: `video/mp4;codecs=avc1,mp4a.40.2`, then `video/webm;codecs=vp9,opus`, then `video/webm`. Be honest in the UI about what format the user is getting. MP4 output from `MediaRecorder` is not available in every browser; do not promise it unconditionally.

Aspect ratios: 9:16 (1080x1920), 16:9 (1920x1080), 1:1 (1080x1080). Render into an offscreen canvas at the target size, letterboxing or cropping the 4:3 camera frame with `object-fit: cover` semantics. Do not stretch.

Countdown of 3 before recording starts, a visible elapsed timer, a hard stop at 30 s, then a preview with download and "record again". Keep the blob in memory and revoke object URLs on unmount.

## 10. Visual design

Dark background. Neon hand skeleton drawn on a canvas layered over the mirrored video, using `shadowBlur` with a colour that shifts by scale degree so the visual and the harmony agree. Draw the 21 landmarks as small filled circles and the standard MediaPipe connection set as lines. Two hands get two hues.

HUD, always visible, minimal:

- Current chord name, large (for example "F#m7").
- Key and mode.
- Two hand-presence pills that go from grey to lit.
- A level meter.

Settings live in a slide-over panel, not a modal, so the user can adjust while playing. Every setting persists to `localStorage`.

First-run onboarding: three cards over a dimmed camera preview. Card one asks for camera permission with a plain-language privacy line. Card two shows the left-hand chord table. Card three shows the right-hand expression map. Replayable from the help panel. Skippable.

## 11. Failure handling

Map `getUserMedia` errors to human sentences, not error codes:

| Error | Message |
|---|---|
| `NotAllowedError` | Camera permission was denied. Click the lock icon in the address bar to allow it, then reload. Or switch to keyboard mode. |
| `NotFoundError` | No camera found. Keyboard mode works without one. |
| `NotReadableError` | Another app is using the camera. Close it and try again. |
| `NotSupportedError` | This page needs HTTPS to reach the camera. |

Also cover: model download failure (retry button), WebGL unavailable (fall back to CPU delegate with a warning), and tracking running under 15 fps (suggest closing other apps, offer to drop camera resolution).

## 12. Performance budget

- Hand detection: 30 fps target, never blocking the audio thread.
- Gesture-to-sound latency: under 100 ms end to end. Measure it; do not assume it.
- Skeleton draw and detect share one rAF loop. One loop total.
- No allocation inside the loop. Reuse typed arrays and point objects.
- Idle CPU when both hands are out of frame should drop; consider throttling detection to 10 fps after two seconds of no hands.

## 13. Milestones

Build in this order and confirm each before moving on.

- **M0** Vite + React + TS skeleton, camera permission flow, mirrored video element, self-hosted MediaPipe loading with progress.
- **M1** Landmarks detected and skeleton drawn at 30 fps. Dev overlay showing per-finger extended booleans, finger count, tilt angle, and measured fps.
- **M2** Audio graph on first click. Fixed chord in key of A plays when the left hand shows one finger. Silence on fist.
- **M3** Full harmony table with hysteresis, all 12 keys, both harmony submodes.
- **M4** Expression hand: volume, filter, octave, Finger Layout styles. Voice-led chord transitions.
- **M5** Arpeggiator, auto bass, metronome on a shared transport.
- **M6** Theremin and Mono Piano modes.
- **M7** Keyboard mode with on-screen map.
- **M8** Recording, all three capture types, all three aspect ratios.
- **M9** Onboarding, help panel, settings persistence, error states, polish.

## 14. Acceptance criteria

The build is done when all of these hold:

1. Cold load to playable in under 5 seconds on a warm cache.
2. Holding a steady 3-finger left hand for 10 seconds produces one chord attack, not repeated retriggers.
3. Moving the right hand from waist to head height produces a smooth volume swell with no zipper noise or clicks.
4. Switching key mid-performance does not drop or stick a voice.
5. Every one of the eight left-hand gestures resolves correctly in 9 of 10 attempts under normal room lighting.
6. Unplugging the camera mid-session shows an error and offers keyboard mode instead of crashing.
7. A 30-second video recording plays back with audio and video in sync in VLC and in a browser.
8. Keyboard mode can play a full I-V-vi-IV progression with no camera connected.
9. Lighthouse accessibility score above 90; all controls keyboard-reachable; skeleton canvas marked `aria-hidden`.
10. No console errors during a five-minute play session.

## 15. Testing

- Unit tests (Vitest) for the pure layers: `theory.ts`, `chords.ts`, `fingers.ts`, `smoothing.ts`. Feed `fingers.ts` recorded landmark fixtures as JSON and assert the classification. This is where most bugs will live and it is fully testable without a camera.
- Record 30 seconds of landmark output to a JSON fixture during development and build a "replay" dev mode that pumps it through the pipeline with no camera. You will use this constantly.
- Manual matrix: Chrome and Firefox on macOS and Windows, with and without a camera, light and dim room.

---

## Reader notes (not part of the prompt)

A few things worth knowing before you hand this off.

**What will actually be hard.** The music theory and the Tone.js graph are a couple of days of work. The gesture classification is where the project lives or dies, and the difference between "impressive demo" and "unplayable" is entirely in section 4.6, the smoothing and hysteresis. Budget disproportionate time there and build the landmark replay fixture early; iterating on threshold constants against a live webcam is miserable.

**The handedness mirror issue** in 4.3 catches nearly everyone building on MediaPipe. I have flagged it rather than asserting which way it resolves, because it depends on how you draw the preview and I have not tested your specific setup.

**Version numbers** in section 2 are what the npm registry returned on 16 August 2026. `@mediapipe/tasks-vision` recently moved to a 1.x line from the long-running 0.10.x series, so older tutorials you find will show slightly different import paths. Trust the current docs over blog posts.

**On the reference site.** It is MIT-licensed and open source per its own FAQ, so you could read its implementation legally. I would still build from the spec first and only consult it when stuck, otherwise you inherit its architecture along with its bugs.

**One thing I would add** that the original does not appear to have: Web MIDI output. Sending note-on and note-off to a DAW instead of only making sound in the tab turns this from a toy into something a musician might actually use. It is maybe 100 lines on top of the existing chord layer.
