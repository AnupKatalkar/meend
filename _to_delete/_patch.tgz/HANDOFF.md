# Handoff

Context for continuing this project in a fresh session.

**To resume:** open this repo in Claude Code and say *"Read HANDOFF.md and continue."*
Copy this file to `CLAUDE.md` if you want it loaded automatically every session.

---

## What this is

A browser-only musical instrument played with hand gestures in front of a
webcam. Two hands tracked at ~30 fps: left picks harmony, right shapes
expression. Fully client-side — no server, no API keys, nothing uploaded.
Deploys as static files.

The original brief is in **`BUILD-SPEC.md`** in this directory. It is the
authority on intended behaviour; read it before changing core behaviour.

---

## Environment gotcha (hit this first)

`node` is **not on PATH** in this shell. It lives under nvm:

```fish
set -x PATH $HOME/.nvm/versions/node/v24.15.0/bin $PATH
```

Shell is fish. macOS.



## Commands

| Command | What |
| --- | --- |
| `npm run dev` | http://localhost:5173 |
| `npm test` | 133 unit tests, no camera or browser needed |
| `npm run test:e2e` | ~57 assertions in real Chrome (fake camera device) |
| `npm run build` | typecheck + production bundle |
| `npm run vendor` | re-fetch MediaPipe model + piano samples into `public/` |
| `node e2e/shots.mjs` | manual: screenshots of each UI state (`OUT=./shots`) |

On a machine without Chrome at the default macOS path, point the suites at a
binary: `CHROME_PATH=/path/to/chrome npm run test:e2e`.

`npm install` vendors ~20 MB (MediaPipe wasm + hand model) and ~1.8 MB (piano
samples) into `public/`. Deploy needs **HTTPS** — `getUserMedia` won't run over
plain HTTP. `localhost` is exempt.

---

## Architecture

```
src/
  vision/     MediaPipe lifecycle, geometry, gesture classification, filtering
  music/      keys, scales, chords, voice leading, ragas, talas  (pure, no Tone)
  audio/      Tone.js graph, instruments, arpeggiator, bass, metronome, tanpura
  modes/      gesture / theremin / mono piano / raga / keyboard
  engine/     Conductor — the single rAF loop, wires everything
  recording/  MediaRecorder + canvas compositing
  state/      zustand store (settings) + telemetry (per-frame, non-React)
  ui/         React panels and HUD + imperative skeleton renderer
```

**The one rule: React never owns per-frame data.** Landmarks, skeleton drawing
and audio-parameter updates run outside React in one rAF loop owned by
`engine/Conductor.ts`. Discrete rare events (chord change, hand appears) go
through the zustand store; anything per-frame goes through
`state/telemetry.ts`, a mutable singleton polled by whoever needs it. Pushing
30 fps through `setState` drops frames.

**Where the risk concentrates:** `vision/smoothing.ts` (One Euro for continuous
values, asymmetric hysteresis for discrete ones) and `vision/fingers.ts`
(rotation-invariant finger extension). These are the difference between an
instrument and a demo. Both are heavily unit-tested.

**Dev handle:** `window.__gestureSynth` exposes `{ conductor, store, telemetry }`
in dev builds — that's what the e2e suites drive.

---

## Built and working

All milestones M0–M9 from the spec, plus these additions made during the
session:

- **Raga mode** (Hindustani) — 13 ragas, tanpura drone (Karplus-Strong, four
  plucked strings), meend/portamento, 6 talas with sam/tali/khali roles and a
  tabla voice. Aroha vs avaroha is modelled: the same gesture is a different
  swara depending on direction of travel.
- **Chord instruments** — Synth (detuned triple-saw) / Electric piano (FM) /
  Grand piano (sampled Salamander, lazy-loaded 1.8 MB, CC-BY, licence in
  `public/samples/piano/LICENSE.txt` + Help panel credit).
- **Chord blend** slider — moves attack, detune spread, release and reverb
  together, from a crisp stab to a fused pad.
- **HUD rewrite** — card above the controls with a live oscilloscope
  (`Tone.Waveform`, real samples, flat when silent), tala strip, hand pills,
  contextual empty state instead of a bare em-dash.
- **Camera quality setting** (480p/720p/1080p, default 720p) — capture
  resolution is now decoupled from detection resolution. Detection always
  downscales to 640 wide via a canvas, so a sharp preview costs no frame rate.
  Verified: 31.6 fps and 27.3 ms latency at 720p capture.

---

## Open items

1. **Rename.** Shortlist below. Nothing is renamed yet. If you pick one, touch:
   `package.json` name, `index.html` `<title>`, the localStorage keys
   `gesture-synth.settings` in `state/store.ts` and `gesture-synth.handedness`
   in `vision/handedness.ts` (bump `version` or migrate, so existing settings
   do not silently reset), the download filename `gesture-synth.{ext}` in
   `ui/RecordControls.tsx`, and the README/HANDOFF headings. One e2e assertion
   in `recording.mjs` checks that download filename and will fail until updated.
2. **Web MIDI output.** Not built, and the best remaining idea. See Deviations.

### Closed since the last handoff

- **Full verification is green**, run on Linux with Node 22: 133 unit tests,
  `tsc --noEmit` clean, production build clean, and all four browser suites
  (`smoke`, `gestures`, `raga`, `recording`) passing against a fake camera
  device. Measured in that run: 30.1 fps, 36.4 ms gesture-to-sound latency, one
  attack per held gesture across four seconds.
- **Handedness is no longer an untested assumption.** It is measured at runtime.
  See `vision/handedness.ts` and the README section. Short version: whenever
  both hands are in frame, their positions give a signal that owes nothing to
  MediaPipe, because in an unmirrored image the player's left hand sits on the
  right of the picture. Twelve consistent votes commit a polarity and persist it
  to `localStorage`. One-handed play and replayed clips do not vote, so the
  documented prior still governs those. A **Reset handedness** button lives in
  the developer panel next to the live reading and its confidence.
- **Landmark clips recorded the wrong labels** whenever MediaPipe reported the
  expression hand first: `Conductor.ts` indexed `rawLabels` (detection order)
  with a position in `[harmony, expression]`. Clips now label by role. Any clip
  saved before this fix may replay with the hands reversed.

### Still needs a human and a real camera

No automated harness reaches these:

- The manual browser matrix (Chrome + Firefox, macOS + Windows, bright and dim
  rooms) with a real pair of hands. Watch the developer panel's handedness line
  move from `assumed` to `measured` within the first second of two-handed play.
  If it settles on `labels direct` rather than `labels inverted`, that is the
  calibrator doing its job, not a bug.
- Threshold tuning against real footage, via the developer panel's landmark
  replay.
- Lighthouse accessibility pass (spec target: >90).

---

## Name shortlist

The current name collides with the reference app (gesturesynthweld.com).

**Drop Mudra.** The earlier shortlist led with it. Wearable Devices Ltd
(Nasdaq: WLDS) ships *Mudra Band* and *Mudra Link*, neural gesture-control
wristbands, and mudra-band.com is live. Same product category, same word, an
operating company with every reason to defend it. Not worth the argument.

Availability below is an RDAP registration check made 17 Aug 2026. It says
whether a domain is registered, not whether a name is free of trademarks. Run
your own search before spending money.

| Name | Meaning | Fit | Domains |
| --- | --- | --- | --- |
| **Meend** | The continuous glide between two notes in Hindustani music, a slide rather than a jump | The most exact name here. Every control in this instrument is a glide: pitch through air in theremin mode, filter through wrist tilt, volume through height. Nothing about it steps | `.com` taken, **`.app` and `.io` free** |
| **Gamak** | Ornamental oscillation on a held note | Names the shimmer instead of the slide. Harder consonants, more percussive than the app feels | `.com` taken, **`.app` and `.io` free** |
| **Anahat** | From *anāhata nāda*, "unstruck sound": sound made without two things striking each other | Conceptually the best of the lot, since an instrument played by moving your hands through empty air is literally unstruck sound. Costs a syllable, and yoga studios have worn the longer form thin | `.com`, `.app` taken; `.io` free |
| **Jhala** | The fast strummed climax of a raga performance | Energetic, easy to say, no baggage | `.com`, `.app` taken; `.io` free |
| **Khayal** | The dominant Hindustani vocal genre; the word means "imagination" | Lovely meaning, but it names a genre rather than a gesture, and the transliteration wobbles (khayal / khyal / kheyal) | `.com`, `.app` taken; `.io` free |
| **Taan** | A fast melodic run | One syllable, memorable, slightly generic | `.com`, `.app` taken; `.io` free |
| **Aircord** | Plain English, no cultural framing | Says what it does, forgettable the way descriptive names are | `.com`, `.app` taken; `.io` free |

Recommendation: **Meend**, on meend.app. Short, pronounceable without
instruction, means the exact thing the instrument does, carries the raga mode
without making the app sound like it only does raga, and it is the only strong
candidate whose `.app` is unregistered. **Anahat** is the pick if you want the
idea over the mechanic.

---

## Deviations from BUILD-SPEC.md

Documented in full in README under "Deviations from the spec". Summary:

1. A ninth chord style, `Diatonic (follows key)`, is the default — the spec's
   eight fixed styles force every degree to one quality, which broke its own
   success criterion ("three fingers → a iii chord").
2. Two files not in the spec's layout: `engine/Conductor.ts` and
   `modes/types.ts`. The spec's file list had no home for either.
3. Mono Piano triggers on pinch only; flick needs a velocity estimate that
   landmark jitter makes unreliable at 30 fps.
4. `vision/handedness.ts` is not in the spec's layout either. The spec pinned
   the mirror problem to "one `MIRRORED = true` constant"; measuring it instead
   of asserting it needs a little more than a constant.

Not built: **Web MIDI output**. It appears only in the spec's "Reader notes
(not part of the prompt)", so it was out of scope — but it is a good idea and
would sit cleanly on `audio/voices.ts`, which already computes note-level
attack/release deltas. Roughly 100 lines.

---
